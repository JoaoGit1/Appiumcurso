package appiumcurso.test;

import io.appium.java_client.MobileElement;

public class tap {
    public tap(MobileElement botao, int i, int i1) {
    }
}
