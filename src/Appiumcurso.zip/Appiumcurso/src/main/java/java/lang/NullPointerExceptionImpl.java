package java.lang;

public class NullPointerExceptionImpl extends NullPointerException {
    public NullPointerExceptionImpl() {
    }
}
